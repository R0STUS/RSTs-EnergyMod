function read(blockid, property)
    blockid = block.name(blockid)
    local separator = ":"

    local separator_index = string.find(blockid, separator)

    if separator_index then
        local contentid = string.sub(blockid, 1, separator_index - 1)
        local block = string.sub(blockid, separator_index + 1)

        path = contentid .. ":blocks/" .. block .. ".json"

        print(path)

        json_data = [[]]

        json_data = file.read(path)

        local value = nil
        local current_pos = 1
        local key, val = nil, nil

        while true do
            while json_data:sub(current_pos, current_pos):match("[%s:,{}]") do
                current_pos = current_pos + 1
            end

            if current_pos > #json_data then
                break
            end

            local start_pos = current_pos
            while json_data:sub(current_pos, current_pos) ~= ":" do
                current_pos = current_pos + 1
            end
            key = json_data:sub(start_pos, current_pos - 1)
            key = key:gsub('"', '')
            current_pos = current_pos + 1

            start_pos = current_pos
            while json_data:sub(current_pos, current_pos) ~= "," and json_data:sub(current_pos, current_pos) ~= "}" do
                current_pos = current_pos + 1
            end
            val = json_data:sub(start_pos, current_pos - 1)

            value = tonumber(val)

            if key == property then
                return value
            end

            if json_data:sub(current_pos, current_pos) == "," then
                current_pos = current_pos + 1
            end
        end

        return nil
    else
        print("Failed to split the blockid.")
    end
end